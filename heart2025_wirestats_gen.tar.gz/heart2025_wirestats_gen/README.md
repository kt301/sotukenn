# yggdrasill

Describe your project here.

CFLAGS="-I$(xcrun --show-sdk-path)/usr/include -I$(brew --prefix graphviz)/include" LDFLAGS="-L$(brew --prefix graphviz)/lib" r
ye add pygraphviz